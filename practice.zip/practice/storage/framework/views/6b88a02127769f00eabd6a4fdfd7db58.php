 <!-- Assuming 'tasks' is the layout you're extending -->
<?php $__env->startSection('title', 'task'); ?> <!-- Corrected the 'titel' to 'title' -->

<?php $__env->startSection('content'); ?>
    <div class="overflow-x-auto shadow-lg rounded-lg border border-gray-300 bg-white">
        <?php if($tasks->isEmpty()): ?>
            <p class="text-red-500 font-medium text-2xl text-center py-4">No Tasks Found</p>
        <?php else: ?>
            <table class="table-auto w-full text-sm text-gray-700">
                <thead>
                    <tr class="bg-indigo-600 text-white">
                        <th class="px-6 py-3 text-left">Serial No</th>
                        <th class="px-6 py-3 text-left">Task Name</th>
                        <th class="px-6 py-3 text-left">Description</th>
                        <th class="px-6 py-3 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b hover:bg-gray-100">
                            <td class="px-6 py-4"><?php echo e($index + 1); ?></td>
                            <td class="px-6 py-4"><?php echo e($task->name); ?></td>
                            <td class="px-6 py-4"><?php echo e($task->description); ?></td>
                            <td class="px-6 py-4">
                                <a href="<?php echo e(route('editTask', $task->id)); ?>"
                                    class="btn btn-primary text-white bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-md mr-2">Edit</a>
                                <form action="<?php echo e(route('deleteTask', $task->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                        class="btn btn-danger text-white bg-red-600 hover:bg-red-700 px-4 py-2 rounded-md">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\practice\resources\views\task.blade.php ENDPATH**/ ?>