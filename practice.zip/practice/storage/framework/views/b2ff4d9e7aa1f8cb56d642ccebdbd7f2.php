;
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>


    <h2 class="text-center uppercase font-serif text-sky-500 text-4xl mb-7">Welcome To Your Dashboard
        <?php echo e(auth()->user()->name); ?>

    </h2>
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                title: 'Success!',
                text: '<?php echo e(session('success')); ?>',
                icon: 'success',
                confirmButtonText: 'Okay',
                timer: '1500'
            });
        </script>
    <?php endif; ?>

    <form action="" method="post" enctype="multipart/form-data" class="bg-gray-900 p-10 w-1/2 mx-auto rounded-md ">
        <p class="text-center text-white text-2xl uppercase font-serif">Create Task</p>
        <?php echo csrf_field(); ?>
        <div class="my-4">
            <input type="hidden" name="user_id" id="user_id" value="<?php echo e(auth()->user()->id); ?>">
            <label for="name" class="text-white text-xl uppercase font-serif">Name</label>
            <input class="w-full p-2 bg-gray-800 text-white" type="text" name="name" id="name"
                placeholder="Enter your Task Name, Titel" value="<?php echo e(old('name')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-500 font-medium text-xs"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="description" class="text-white text-xl uppercase font-serif">Desription</label>

            <textarea class="w-full p-2 bg-gray-800 text-white" rows="6" name="description" id="description"
                placeholder="Enter Your Task Description" value="<?php echo e(old('description')); ?>"></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-500 font-medium text-xs"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button
            class="bg-sky-500 hover:bg-green-500 text-xl font-medium font-serif text-white rounded-sm mt-5 w-full py-3 uppercase leading-tight"
            type="submit">Create Task</button>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\practice\resources\views\dashboard.blade.php ENDPATH**/ ?>