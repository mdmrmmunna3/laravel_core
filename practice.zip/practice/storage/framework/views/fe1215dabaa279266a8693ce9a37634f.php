<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title><?php echo $__env->yieldContent('title', 'Home'); ?></title>
</head>

<body>
    <!-- Navbar -->
    <div class="navbar bg-base-100 overflow-hidden px-10">
        <?php if(session('success')): ?>
            <script>
                Swal.fire({
                    title: 'Success!',
                    text: '<?php echo e(session('success')); ?>',
                    icon: 'success',
                    confirmButtonText: 'Okay',
                    timer: '1500'
                });
            </script>
        <?php endif; ?>
        <div class="navbar-start">
            <div class="dropdown">
                <div tabindex="0" role="button" class="btn btn-ghost lg:hidden">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h8m-8 6h16" />
                    </svg>
                </div>
                <ul tabindex="0"
                    class="menu menu-sm dropdown-content bg-base-100 rounded-box z-[1] mt-3 w-52 p-2 shadow">
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>">Add task</a>
                    </li>
                    <li><a href="<?php echo e(route('task')); ?>">View Task</a></li>
                </ul>
            </div>
            <a href="/" class="btn btn-ghost text-xl">daisyUI</a>
        </div>
        <div class="navbar-center hidden lg:flex">
            <ul class="menu menu-horizontal px-1">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>">Add task</a>
                </li>
                <li><a href="<?php echo e(route('task')); ?>">View Task</a></li>
            </ul>
        </div>
        <div class="navbar-end">
            <?php if(Route::has('login')): ?>
                <nav class="-mx-3 flex flex-1 justify-end">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/dashboard')); ?>"
                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white">
                            Dashboard
                        </a>

                        <form action="<?php echo e(route('logout')); ?>"
                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white flex justify-center items-center cursor-pointer"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit">Logout</button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>"
                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white">
                            Log in
                        </a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>"
                                class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white">
                                Register
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>

                </nav>
            <?php endif; ?>



        </div>
    </div>

    <!-- Main Content -->
    <div class="container mx-auto py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Optional: You can include any global JS or scripts here -->
</body>

</html><?php /**PATH D:\xampp\htdocs\laravel\practice\resources\views/home.blade.php ENDPATH**/ ?>